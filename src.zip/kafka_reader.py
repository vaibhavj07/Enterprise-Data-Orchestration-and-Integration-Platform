from pyspark.sql import SparkSession

def read_from_kafka(spark, kafka_config):
    return spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", kafka_config['bootstrap_servers']) \
        .option("subscribe", kafka_config['subscribe_topic']) \
        .load()