import argparse
import logging
import json
from logging_utils import setup_logging
from kafka_reader import read_from_kafka
from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col, to_date
from pyspark.sql.types import StructType, StructField, StringType, FloatType, TimestampType, ArrayType
import os
import sys
from pathlib import Path

# Set up logging
logger = setup_logging()

# Argument parser
parser = argparse.ArgumentParser(description="Event Loader Consumer")
parser.add_argument('--kafka-broker', required=True, help="Kafka broker address")
parser.add_argument('--kafka-topic', required=True, help="Kafka topic")
parser.add_argument('--spark-app-name', required=True, help="Spark application name")
parser.add_argument('--spark-master', required=True, help="Spark master URL")
parser.add_argument('--landing-zone-path', required=True, help="HDFS landing zone path")
parser.add_argument('--checkpoint-location', required=True, help="HDFS checkpoint location")
parser.add_argument('--spark-configs', required=True, help="Spark configurations as a JSON string")
args = parser.parse_args()

# Log current directory and Python path
logger.info("Current working directory: %s", os.getcwd())
logger.info("Python path: %s", sys.path)

# Walk through the directory to log all files
for root, dirs, files in os.walk("."):
    for name in files:
        logger.info(os.path.join(root, name))
    for name in dirs:
        logger.info(os.path.join(root, name))

logger.info("success...1")

# Log all the arguments
logger.info("Kafka Broker: %s", args.kafka_broker)
logger.info("Kafka Topic: %s", args.kafka_topic)
logger.info("Spark App Name: %s", args.spark_app_name)
logger.info("Spark Master: %s", args.spark_master)
logger.info("Landing Zone Path: %s", args.landing_zone_path)
logger.info("Checkpoint Location: %s", args.checkpoint_location)
logger.info("Spark Configs: %s", args.spark_configs)

# Create Spark session
spark_configs = json.loads(args.spark_configs)
def create_spark_session(app_name, master, spark_configs):
    try:
        spark = SparkSession.builder \
            .appName(app_name) \
            .master(master) \
            .enableHiveSupport()
        
        for key, value in spark_configs.items():
            spark = spark.config(key, value)
        
        spark = spark.getOrCreate()
        logger.info("Spark session initialized.")
        return spark
    except Exception as e:
        logger.error(f"Error creating Spark session: {e}")
        return None

spark = create_spark_session(
    app_name=args.spark_app_name,
    master=args.spark_master,
    spark_configs=spark_configs
)
if not spark:
    raise Exception("Failed to create Spark session")

# Define schema for incoming data
schema = StructType([
    StructField("event_id", StringType(), True),
    StructField("user_id", StringType(), True),
    StructField("page_url", StringType(), True),
    StructField("timestamp", StringType(), True),
    StructField("event_type", StringType(), True),
    StructField("referrer", StringType(), True),
    StructField("interaction_id", StringType(), True),
    StructField("product_id", StringType(), True),
    StructField("interaction_type", StringType(), True),
    StructField("session_id", StringType(), True),
    StructField("conversion_id", StringType(), True),
    StructField("campaign_id", StringType(), True),
    StructField("conversion_value", FloatType(), True),
    StructField("signup_id", StringType(), True),
    StructField("email", StringType(), True),
    StructField("signup_source", StringType(), True),
    StructField("start_time", StringType(), True),
    StructField("end_time", StringType(), True),
    StructField("duration", FloatType(), True),
    StructField("pages_viewed", StringType(), True),
    StructField("actions", ArrayType(StringType()), True)
])

logger.info("Schema defined.")

# Read data from Kafka
kafka_config = {
    "bootstrap_servers": args.kafka_broker,
    "subscribe_topic": args.kafka_topic
}

df = read_from_kafka(spark, kafka_config)

logger.info("Data read from Kafka.")

# Convert value column to string
df = df.selectExpr("CAST(value AS STRING)")

# Parse JSON data and apply schema
df = df.select(from_json(col("value"), schema).alias("data")).select("data.*")

# Convert timestamp column to TimestampType
df = df.withColumn("timestamp", col("timestamp").cast(TimestampType()))

# Extract date from timestamp for partitioning
df = df.withColumn("date", to_date(col("timestamp")))

# Write raw data to HDFS partitioned by date
hdfs_query = df.writeStream \
    .outputMode("append") \
    .format("parquet") \
    .option("path", args.landing_zone_path) \
    .option("checkpointLocation", args.checkpoint_location) \
    .partitionBy("date") \
    .start()

logger.info("Writing data to HDFS.")

try:
    hdfs_query.awaitTermination()
except Exception as e:
    logger.error("Error during stream processing: %s", str(e))
    hdfs_query.stop()
